# the script does all the process of the precipitation data from collection to pre-processing

comnibedPrcpNCDC{

writeLine("stdout", "starting Mega Rule");

# process precipitation data from study area
processncdcPrcp("run_convert_prcp.scr", "", "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", "Done with process precipitation data from study area");

# formatting the combined data
readPreprocDly("inputPrcp.scr", "./cmd/prcp.daily ./cmd/prcp.inf ./cmd/basin_prcp.fmt \"1998 2007\"",  "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", "Done with formatting the combined data");

# time of adjustment of the combined data
precTobAdj("prcp_tobAdj.scr", "./cmd/prec_tob_adj.input",  "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", "Done with time of adjustment of the combined data");

# create mask (ascii file) for the study area
createMask("run_convert_tif_ascii.scr", "",  "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", "Done with create mask (ascii file) for the study area");

# regridding the precipitation data for the basin
#regridPrcp("regrd_prcp.scr", "", "ec2-54-86-215-185.compute-1.amazonaws.com")


# estimate monthly precipitation from NCDC data
mkMonthlyPrcp("mk_monthly_ir.scr", "", "ec2-54-86-215-185.compute-1.amazonaws.com")
writeLine("stdout", " estimate monthly precipitation from NCDC data");

# estimate monthly PRISM data 
mkPrism("get_prism_ir.scr", "", "ec2-54-86-215-185.compute-1.amazonaws.com")
writeLine("stdout", "estimate monthly PRISM data");

# rescaling the precipitation data
mkRescale("rescale_ir.scr", "", "ec2-54-86-215-185.compute-1.amazonaws.com")
writeLine("stdout", "rescaling the precipitation data");

# process maximum temperature data from study area
processncdcTmax("run_convert_tmax.scr", "", "ec2-54-86-215-185.compute-1.amazonaws.com")
writeLine("stdout", "process maximum temperature data from study area");

# formatting the combined data
readPreprocTmaxDly("inputTmax.scr", "./cmd/Tmax/tmax.daily ./cmd/Tmax/tmax.inf ./cmd/Tmax/basin_tmax.fmt \"1998 2007\"", "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", "formatting the combined data");


# time of adjustment of the combined data
tmaxTobAdj("tmax_tobAdj.scr", "./cmd/Tmax/tmax_tob_adj.input", "ec2-54-86-215-185.compute-1.amazonaws.com")


writeLine("stdout", "time of adjustment of the combined data");

# regridding the maximum temperature data for the basin
regridTmax("regrd_tmax.scr", "", "ec2-54-86-215-185.compute-1.amazonaws.com")


writeLine("stdout", "regridding the maximum temperature data for the basin");

# process minimum temperature data from study area
processncdcTmin("run_convert_tmin.scr", "", "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", "process minimum temperature data from study area");

# formatting the combined data
readPreprocTminDly("inputTmin.scr", "./cmd/Tmin/tmin.daily ./cmd/Tmin/tmin.inf ./cmd/Tmin/basin_tmin.fmt \"1998 2007\"", "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", "formatting the combined data");

# time of adjustment of the combined data
tminTobAdj("tmin_tobAdj.scr", "./cmd/Tmin/tmin_tob_adj.input", "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", " time of adjustment of the combined data");

# regridding the minimum temperature data for the basin
regridTmin("regrd_tmin.scr", "", "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", " regridding the minimum temperature data for the basin");

# run meteorological data (prcp_grid.rsc, tmax_grid.grd and tmin_grid.grd) to create gridded data for the study area.
vicInputMeteoData("run_vicinput_ir.scr", "", "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", "run meteorological data (prcp_grid.rsc, tmax_grid.grd and tmin_grid.grd) to create gridded data for the study area.");

# collect wind speed data from NCEP/NCAR 
getNCARwind("getwind.scr", "", "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", "collect wind speed data from NCEP/NCAR");

# regridding the NCEP/NCAR wind speed data
regridNCARwind("run_regrid_wind_ir.scr", "", "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", "regridding the NCEP/NCAR wind speed data");

# combine the wind data with meteorological data
combineWind("run_combine_wind_ir.scr","", "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", " combine the wind data with meteorological data");

# adding preproc and append data into a combined file.
latlonSoil("ldas_latlon.scr", "./cmd/Basin/mask_125.asc ./cmd/latlon.txt", "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", "adding preproc and append data into a combined file.");

# prepare soil data
ldasSoil("ldas_soil.scr", "./cmd/LDAS/soil/soil_ldas.txt ./cmd/LDAS/soil/latlon.txt ./cmd/soil/ldassoildata.txt", "ec2-54-86-215-185.compute-1.amazonaws.com")

writeLine("stdout", " prepare soil data");

# prepare vegetation data
ldasVeg("ldas_veg.scr", "./cmd/LDAS/vegetation/ldas_lai.expanded.vegparams ./cmd/soil/ldassoildata.txt ./cmd/vegetation/ldasvegdata.txt", "ec2-54-86-215-185.compute-1.amazonaws.com")
writeLine("stdout", "prepare vegetation data");

}



# process precipitation data from study area
processncdcPrcp(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);

}

# processing historical input data and output a single file
readPreprocDly(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}


# time of observation of the combined precipitation data
precTobAdj(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}


# create mask (ascii file) for the study area
createMask(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}


# regirdding the precipitation data 
regridPrcp(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}


# making monthly averaged precipitation data 
mkMonthlyPrcp(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}


# get monthly averaged PRISM precipitation data 
mkPrism(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}


# rescale the precipitation data 
mkRescale(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}



# process maximum temperature data from study area
processncdcTmax(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);

}


# processing historical input data and output a single file
readPreprocTmaxDly(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}

# time of observation of the combined maximum temperature data
tmaxTobAdj(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}


# regirdding the maximum temperature data 
regridTmax(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}


# process minimum temperature data from study area
processncdcTmin(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}

# processing historical input data and output a single file
readPreprocTminDly(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}

# time of observation of the combined minimum temperature data
tminTobAdj(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}


# regirdding the minimum temperature data 
regridTmin(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}


# run meteorological data (prcp_grid.rsc, tmax_grid.grd and tmin_grid.grd) to create gridded data for the study area.
vicInputMeteoData(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);

}


# collect wind speed data from NCEP/NCAR 
getNCARwind(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);

}

# regridding the NCEP/NCAR wind speed data
regridNCARwind(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);

}

# combine the wind data with meteorological data
combineWind(*Cmd, *Arg, *Host){
   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);

}

latlonSoil(*Cmd, *Arg, *Host){
# adding latlon of the study region.

   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}




ldasSoil(*Cmd, *Arg, *Host){
# adding soil data from LDAS.

   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}



ldasVeg(*Cmd, *Arg, *Host){
# adding vegetation data from LDAS.

   msiExecCmd(*Cmd,*Arg, *Host,"null","null",*Result);
   msiGetStdoutInExecCmdOut(*Result,*Out);
}


INPUT null
OUTPUT ruleExecOut


